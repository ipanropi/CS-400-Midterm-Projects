import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;


public class Frontend implements FrontendInterface {
  Scanner sc;
  BackendImplementation ref;
  boolean fileNotLoaded = true;

  public Frontend(Scanner sc, BackendImplementation ref) {
    this.sc = sc;
    this.ref = ref;
  }

  public void mainMenuLoop() {
    int choice;

    do {

      System.out.println("Welcome to Song Searcher!");
      loadFile();
      System.out.println("finish loading file");
    }while (fileNotLoaded);

    do {

      System.out.println("Please choose from the following options:");
      System.out.println("1. Load another file");
      System.out.println("2. List songs by score");
      System.out.println("3. Show average score");
      System.out.println("4. Exit");

      System.out.println("Enter your choice: ");
      choice = sc.nextInt();
      sc.nextLine();

      if (choice < 1 || choice > 4) {
        System.out.println("Invalid input. Please enter a number between 1 and 4 only!");
        continue;
      }

      System.out.println("You chose: " + choice + "\n");
      switch (choice) {
        case 1 -> loadFile();
        case 2 -> listSongsByScore();
        case 3 -> showAvgScore();
        case 4 -> exitApp();
      }

    } while (choice != 4);
  }
  public void loadFile() {
    String path;

    boolean isNotValid = true;

    do {
      System.out.println("Enter the file path: ");
      path = sc.nextLine();

      isNotValid = !ref.loadData(path);

      if (isNotValid){
        System.out.println("You entered non existent or unvalid file path! Please try again!");
      }
    } while (isNotValid);
    fileNotLoaded = false;
    System.out.println("File loaded successfully! The file name is : " + path);
  }

  public void listSongsByScore() {
    int danceScore;
    do {
      System.out.println("Enter the danceability score: ");
      danceScore = sc.nextInt();
      sc.nextLine();

      if (danceScore < 0 || danceScore > 100) {
        System.out.println("Invalid input. Please enter a number between 0 and 100 only!");
      }

    } while (danceScore < 0 || danceScore > 100);

    ArrayList<SongInterface> songsAboveThreshold;
    songsAboveThreshold = ref.getSongsAboveThreshold(danceScore);

    System.out.println("The songs with danceability score above " + danceScore + " are: ");
    for (SongInterface song : songsAboveThreshold) {
      System.out.println(song.toString());
    }
  }

  public void showAvgScore() {
    // getting calculated avg score from backend class

    double avg = ref.getAverageDanceability();
    System.out.println("The average danceability score is: " + avg);

  }

  public void exitApp() {
    System.out.println("Thank you for using Song Searcher!");

  }

  public static void main(String[] args) {

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object
    BackendImplementation backend = new BackendImplementation(placeholder);

    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);


    // calling listSongsByScore method that prompt the user for the score
    songSearcher.mainMenuLoop();
  }
}
