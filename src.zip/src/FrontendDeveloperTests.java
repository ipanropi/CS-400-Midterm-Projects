import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Scanner;

/**
 * This class contains tests for functionalities provided by the frontend of the application,
 * mainly simulating a user's interactions and ensuring the frontend behaves as expected.
 */
public class FrontendDeveloperTests {

  /**
   * Test the functionality of loadfile menu.
   * This method simulates a user trying to load a file named 'data.csv'.
   * It checks if the frontend asks for the file path and attempts to load it.
   */
  @Test
  public void testLoadFile() {
    // Initialize tester with inputs for loading a file
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);
    //creating backend placeholder
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // calling loadFile method that prompt the user for the file path
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();
    System.out.println(output);

    // Validate the output for successful file load
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") && output.contains("SmallSampleData.csv"));
  }

  /**
   * Test the functionality for prompting user to list songs based on a specific score.
   * This method simulates a user trying to list songs with a danceability score of 100.
   */
  @Test
  public void testListSongsByScore() {
    // Initialize tester with inputs to list songs by a specific score
    TextUITester test = new TextUITester("1\nsrc/SmallSampleData.csv\n2\n60\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // calling listSongsByScore method that prompt the user for the score
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();
    System.out.println(output);
    System.out.println();

    // Validate the output for the expected song score
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") && output.contains("Hey, Soul Sister"));
  }

  /**
   * Test the functionality to display the average danceability score of all songs.
   * It ensures the frontend correctly displays the average score.
   */
  @Test
  public void testShowAvgScore() {
    // Initialize tester with inputs to display average score
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n3\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // Display the average score of all songs
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();
    System.out.println(output);

    // Validate the output for the expected average score
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") && output.contains("70.4"));
  }

  /**
   * Test the functionality of the main menu loop.
   * This method ensures that the frontend's main menu is behaving as expected
   * and respond appropriately without crashing.
   */
  @Test
  public void testMainMenuLoop() {
    // Initialize tester with an invalid main menu option
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n5\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // calling mainMenuLoop method that prompt the user for the main menu option
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();

    // Validate the output for an invalid input message
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") && output.contains("Invalid input. Please enter a number between 1 and 4 only!"));
  }

  /**
   * Test the functionality of exiting the application.
   * This method ensures that the frontend can handle an exit command and
   * provide a message to the user.
   */
  @Test
  public void testExitApp(){
    // Initialize tester that simulates a user trying to exit the application
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // calling mainMenuLoop method that prompt the user for the main menu option, in this case exit the program
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();

    // Validate the output for an invalid input message
    Assertions.assertTrue(output.contains("Thank you for using Song Searcher!"));

  }

  /**
   * Test the functionality of the integration of frontend and backend. This method ensures that
   * the frontend will output the expected output when the user chooses to list songs above a certain.
   * This method also check if backend is calculating and returning the expected value of
   * average of danceability.
   */
  @Test
  public void testGetAverageDanceabilityIntegration(){
    // Initialize tester with inputs to display average score
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n3\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    // Display the average score of all songs
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();

    // Validate the output for the expected average score
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") &&
        output.contains("The average danceability score is: "));

    //Testing backend getAverageDanceability method
    Assertions.assertEquals(70.4, backend.getAverageDanceability());
  }

  /**
   * Test the functionality of the integration of frontend and backend. This method ensures that
   * the frontend will output the expected output when the user chooses to list songs above a certain.
   * This method also check if backend is returning the expected song with score above threshold.
   */
  @Test
  public void testGetSongsAboveThresholdIntegration(){
    // Initialize tester with inputs to display average score
    TextUITester test = new TextUITester("src/songs.csv\n2\n70\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);

    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);


    // calling listSongsByScore method that prompt the user for the score
    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();

    //Check if frontend work as intended
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") &&
        output.contains("Enter the danceability score: ") &&
        output.contains("Thank you for using Song Searcher!"));

    //checking backend songList have right number of song with score above threshold

    // checking if song danceability is > 80
    for (SongInterface song : backend.getSongsAboveThreshold(70)) {
      System.out.println(song.getDanceability());
      boolean isAboveThreshold = song.getDanceability() >= 70;
      Assertions.assertTrue(isAboveThreshold);
    }


  }


  /**
   * Test the functionality of the integration of frontend and backend. This method ensures that
   * the frontend will output the expected output when the user chooses to load a file.
   * This method also check if backend is returning the expected behavior when asked to load a 
   * nonexistent file.
   */
  @Test
  public void testLoadDataIntegration(){
    // Initialize tester with inputs to display average score
    TextUITester test = new TextUITester("src/SmallSampleData.csv\n4\n");

    //creating scanner object
    Scanner in = new Scanner(System.in);

    //creating backend placeholder                                                                                                                              
    IterableMultiKeyRBT<Integer> placeholder = new IterableMultiKeyRBT<>();
    //creating backend object                                                                                                                                   
    BackendImplementation backend = new BackendImplementation(placeholder);
    // Instantiate and run the frontend object
    Frontend songSearcher = new Frontend(in, backend);

    songSearcher.mainMenuLoop();

    // Retrieve the output from the tester
    String output = test.checkOutput();

    // Validate the output for successful file load
    Assertions.assertTrue(output.startsWith("Welcome to Song Searcher!") &&
        output.contains("File loaded successfully! The file name is : src/SmallSampleData.csv"));

    //testing backend loadData method
    boolean loadedFile = backend.loadData("src/SmallSampledata.csv");

    //check if backend return expected output.
    Assertions.assertTrue(loadedFile);
  }

}
