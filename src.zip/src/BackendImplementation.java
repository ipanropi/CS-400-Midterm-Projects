import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class BackendImplementation implements BackendInterface{
  IterableMultiKeySortedCollectionInterface songs;

  public BackendImplementation(IterableMultiKeySortedCollectionInterface iter){
    this.songs = iter;
  }

  /**
   * loads data from a file containing the data
   * @param filename the path to the file containing the data
   * @return True if the data is successfully loaded, False otherwise
   */
  @Override
  public boolean loadData(String filename){
    //using buffered reader to load the csv
    try(BufferedReader br = new BufferedReader(new FileReader(filename))){
      String line;
      br.readLine(); //skipping the header
      while((line = br.readLine()) != null){

        //getting all columns as an array of strings of length 14
        String[] values = parseCSVLine(line);


        //defining temp values from csv
        String title = values[0];
        String artist = values[1];
        String genre = values[2];
        int year = Integer.parseInt(values[3]);
        int dance = Integer.parseInt(values[6]);

        //creating a new song and adding this into the song ArrayList
        Song song = new Song(title, artist, year, genre, dance);
        System.out.println(song.toString());
        this.songs.insertSingleKey(song);
      }
    }
    catch (Exception e){
      return false; //error occurred while loading data
    }
    return true; //successfully loaded data
  }

  private String[] parseCSVLine(String line) {
    ArrayList<String> values = new ArrayList<>();

    StringBuilder currentValue = new StringBuilder();
    boolean insideQuotes = false;

    for (char c : line.toCharArray()) {
      if (c == '"') {
        insideQuotes = !insideQuotes;
        continue; // skip the double-quote character itself
      }

      // If we encounter a comma and we're not inside quotes,
      // it's a column separator
      if (c == ',' && !insideQuotes) {
        values.add(currentValue.toString().trim()); // Add the accumulated value to the list
        currentValue.setLength(0); // Reset the StringBuilder for the next column
      } else {
        currentValue.append(c);
      }
    }

    // Add the last value (as it doesn't end with a comma)
    values.add(currentValue.toString().trim());

    return values.toArray(new String[0]);
  }

  /**
   * This method lists the average danceability of all songs
   * @return the average danceability
   */
  @Override
  public double getAverageDanceability(){
    //keeping track of the sum of danceability scores and the number of songs (for average calculation)
    int totalDanceability = 0;
    int arraySize = this.songs.size();

    //using an advanced for-loop
    for (Object o: this.songs){

      //o needs to be Song
      if(!(o instanceof Song) ){
        throw new IllegalArgumentException("Not a song");
      }

      //castin git
      Song song = (Song) o;

      totalDanceability += song.getDanceability();
    }

    double average = ((double) totalDanceability) / ((double) arraySize);

    return average;
  }

  /**
   * Get a list of all songs with danceability score above or equal to a minimum specific threshold
   * @param threshold the minimum danceability score
   * @return
   */
  @Override
  public ArrayList<SongInterface> getSongsAboveThreshold(int threshold) {
    ArrayList<SongInterface> result = new ArrayList<>();

    for (Object o : this.songs) {
      //o needs to be Song
      if (!(o instanceof Song)) {
        throw new IllegalArgumentException("Not a song");
      }
      //casting
      Song song = (Song) o;
      if (song.getDanceability() >= threshold) {
        result.add(song);
      }
    }
    return result;
  }
}
